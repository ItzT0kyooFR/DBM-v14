module.exports = {
  name: "Delete Bulk Messages",
  isEvent: true,

  fields: [
    "Temp Variable Name (stores list of messages):",
    "Temp Variable Name (stores amount of messages):",
  ],

  mod(DBM) {
    DBM.Events = DBM.Events || {};
    const { Bot, Actions } = DBM;

    DBM.Events.messageDeleteBulk = function messageDeleteBulk(messagesList) {
      if (!Bot.$evts["Delete Bulk Messages"]) return;
      const server = messagesList.first()?.guild;
      if (!server) return;

      for (const event of Bot.$evts["Delete Bulk Messages"]) {
        const temp = {};
        if (event.temp) temp[event.temp] = Array.from(messagesList.values());
        if (event.temp2) temp[event.temp2] = messagesList.size;
        Actions.invokeEvent(event, server, temp);
      }
    };

    const { onReady } = Bot;
    Bot.onReady = function messageDeleteBulkOnReady(...params) {
      Bot.bot.on("messageDeleteBulk", DBM.Events.messageDeleteBulk);
      onReady.apply(this, params);
    };
  },
};
